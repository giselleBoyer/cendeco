<?php
include(ABSPATH . "/.fw-config.php");
